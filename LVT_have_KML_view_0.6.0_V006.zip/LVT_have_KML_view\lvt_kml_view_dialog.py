import os
import re
from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QWidget, 
    QLabel, QComboBox, QLineEdit, QPushButton, QSpinBox, 
    QFileDialog, QMessageBox, QTableWidget, QTableWidgetItem,
    QHeaderView, QCheckBox, QColorDialog, QGroupBox, QTextEdit,
    QSlider, QRadioButton, QButtonGroup, QScrollArea, QFrame
)
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QIcon, QColor, QPainter, QPen, QBrush, QPixmap
from qgis.core import QgsProject, QgsVectorLayer

from .i18n import tr, get_help
from .config_manager import ConfigManager
from .kml_builder import KmlBuilder
from .kml_to_shp import KmlToShpConverter
from .html_template import HtmlTemplateBuilder

class LvtKmlViewDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.bg_img = os.path.join(self.plugin_dir, "google_maps_satellite_bg.png")
        self.config_manager = ConfigManager()
        self.lang = 'vi'
        
        self.setMinimumSize(1000, 900) # Wider for Live Preview
        self._setup_ui()
        self._load_current_layers()
        self._refresh_ui_text()
        self._connect_live_preview()

    def _setup_ui(self):
        main_layout = QHBoxLayout(self)
        
        # LEFT PANE: Settings
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 10, 0)
        main_layout.addWidget(left_widget, 6) # 60% width

        # Language Bar
        top_layout = QHBoxLayout()
        self.btn_lang = QPushButton(); self.btn_lang.setFixedWidth(100)
        self.btn_lang.clicked.connect(self._toggle_language)
        top_layout.addWidget(self.btn_lang); top_layout.addStretch()
        left_layout.addLayout(top_layout)

        self.tabs = QTabWidget(); left_layout.addWidget(self.tabs)
        
        # Tab 1: SHP -> KML
        self.tab_shp2kml = QWidget(); self._setup_tab_shp2kml(); self.tabs.addTab(self.tab_shp2kml, "SHP → KML")
        # Tab 2: KML -> SHP
        self.tab_kml2shp = QWidget(); self._setup_tab_kml2shp(); self.tabs.addTab(self.tab_kml2shp, "KML → SHP")
        # Tab 3: Guide
        self.tab_guide = QWidget(); self._setup_tab_guide(); self.tabs.addTab(self.tab_guide, tr('tab_help', self.lang))
        # Tab 4: Author
        self.tab_author = QWidget(); self._setup_tab_author(); self.tabs.addTab(self.tab_author, "Tác giả")

        # Bottom Buttons
        btn_layout = QHBoxLayout()
        self.btn_save_cfg = QPushButton(tr('btn_save_cfg', self.lang)); self.btn_save_cfg.setIcon(QIcon(':/images/themes/default/mActionFileSave.svg'))
        self.btn_load_cfg = QPushButton(tr('btn_load_cfg', self.lang)); self.btn_load_cfg.setIcon(QIcon(':/images/themes/default/mActionFolder.svg'))
        self.btn_close = QPushButton(tr('btn_cancel', self.lang)); self.btn_close.setIcon(QIcon(':/images/themes/default/mActionDelete.svg'))
        btn_layout.addWidget(self.btn_save_cfg); btn_layout.addWidget(self.btn_load_cfg); btn_layout.addStretch(); btn_layout.addWidget(self.btn_close)
        left_layout.addLayout(btn_layout)

        # RIGHT PANE: Live Preview
        right_widget = QGroupBox("LIVE PREVIEW")
        right_layout = QVBoxLayout(right_widget)
        main_layout.addWidget(right_widget, 4) # 40% width

        # Polygon Preview Box
        right_layout.addWidget(QLabel("<b>Polygon Preview (Contrast Test):</b>"))
        self.poly_preview = QFrame()
        self.poly_preview.setFixedSize(350, 200)
        self.poly_preview.setFrameStyle(QFrame.StyledPanel | QFrame.Sunken)
        self.poly_preview.setStyleSheet(f"background-image: url({self.bg_img.replace('\\', '/')}); background-position: center;")
        self.poly_preview.paintEvent = self._paint_poly_preview
        right_layout.addWidget(self.poly_preview)

        # Popup Preview Box
        right_layout.addWidget(QLabel("<b>Popup Preview:</b>"))
        self.html_preview = QTextEdit()
        self.html_preview.setReadOnly(True)
        right_layout.addWidget(self.html_preview)
        
        self.btn_export_big = QPushButton("🚀 EXPORT KML")
        self.btn_export_big.setMinimumHeight(50)
        self.btn_export_big.setStyleSheet("background-color: #2E7D32; color: white; font-weight: bold; font-size: 16px")
        self.btn_export_big.clicked.connect(self._export)
        right_layout.addWidget(self.btn_export_big)

    def _setup_tab_shp2kml(self):
        layout = QVBoxLayout(self.tab_shp2kml)
        
        # Section 1-5 (Same as V005 but tighter)
        self.gp_io = QGroupBox("1. Input / Output"); io_ly = QVBoxLayout()
        r1 = QHBoxLayout(); r1.addWidget(QLabel("SHP:")); self.txt_shp = QLineEdit(); r1.addWidget(self.txt_shp, 1)
        r1.addWidget(QLabel("Out:")); self.rad_kmz = QRadioButton("KMZ"); self.rad_kmz.setChecked(True); r1.addWidget(self.rad_kmz)
        io_ly.addLayout(r1)
        r2 = QHBoxLayout(); r2.addWidget(QLabel("Layer:")); self.cbo_layers = QComboBox(); r2.addWidget(self.cbo_layers, 1); io_ly.addLayout(r2)
        self.gp_io.setLayout(io_ly); layout.addWidget(self.gp_io)

        self.gp_name = QGroupBox("2. Name Settings"); n_ly = QHBoxLayout()
        self.cbo_name1 = QComboBox(); self.txt_sep = QLineEdit(" - "); self.cbo_name2 = QComboBox()
        n_ly.addWidget(QLabel("F1:")); n_ly.addWidget(self.cbo_name1, 1); n_ly.addWidget(QLabel("Sep:")); n_ly.addWidget(self.txt_sep); n_ly.addWidget(QLabel("F2:")); n_ly.addWidget(self.cbo_name2, 1)
        self.gp_name.setLayout(n_ly); layout.addWidget(self.gp_name)

        self.gp_desc = QGroupBox("3. Popup Fields"); d_ly = QVBoxLayout()
        self.tbl_fields = QTableWidget(0, 4); self.tbl_fields.setHorizontalHeaderLabels(["√", "Field", "Alias", "Unit"])
        self.tbl_fields.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); d_ly.addWidget(self.tbl_fields)
        self.gp_desc.setLayout(d_ly); layout.addWidget(self.gp_desc)

        self.gp_poly = QGroupBox("4. Style"); p_ly = QHBoxLayout()
        self.btn_border = QPushButton("#FF0000"); self.spn_width = QSpinBox(); self.btn_fill = QPushButton("#00FF00"); self.sld_op = QSlider(Qt.Horizontal)
        self.sld_op.setRange(0, 100); self.sld_op.setValue(50)
        p_ly.addWidget(QLabel("V:")); p_ly.addWidget(self.btn_border); p_ly.addWidget(QLabel("W:")); p_ly.addWidget(self.spn_width); p_ly.addWidget(QLabel("N:")); p_ly.addWidget(self.btn_fill); p_ly.addWidget(QLabel("Op:")); p_ly.addWidget(self.sld_op)
        self.gp_poly.setLayout(p_ly); layout.addWidget(self.gp_poly)

        self.gp_hl = QGroupBox("5. Highlighting"); hl_ly = QVBoxLayout()
        r3 = QHBoxLayout(); self.txt_h_title = QLineEdit("Thông tin"); self.btn_h_bg = QPushButton("#1B5E20"); r3.addWidget(QLabel("Title:")); r3.addWidget(self.txt_h_title, 1); r3.addWidget(QLabel("BG:")); r3.addWidget(self.btn_h_bg)
        hl_ly.addLayout(r3); self.chk_row_hl = QCheckBox("Enable Highlighting"); hl_ly.addWidget(self.chk_row_hl)
        self.tbl_rules = QTableWidget(0, 5); self.tbl_rules.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch); hl_ly.addWidget(self.tbl_rules)
        r4 = QHBoxLayout(); btn_add = QPushButton("+"); btn_del = QPushButton("-"); btn_add.clicked.connect(self._add_rule); btn_del.clicked.connect(self._del_rule); r4.addWidget(btn_add); r4.addWidget(btn_del); r4.addStretch()
        hl_ly.addLayout(r4); self.gp_hl.setLayout(hl_ly); layout.addWidget(self.gp_hl)

    def _connect_live_preview(self):
        # Connect everything to _trigger_refresh
        widgets = [self.cbo_name1, self.cbo_name2, self.txt_sep, self.sld_op, self.spn_width, self.txt_h_title, self.chk_row_hl]
        for w in widgets:
            if hasattr(w, 'currentIndexChanged'): w.currentIndexChanged.connect(self._trigger_refresh)
            if hasattr(w, 'textChanged'): w.textChanged.connect(self._trigger_refresh)
            if hasattr(w, 'valueChanged'): w.valueChanged.connect(self._trigger_refresh)
            if hasattr(w, 'toggled'): w.toggled.connect(self._trigger_refresh)
        
        self.btn_border.clicked.connect(lambda: (self._pick_color(self.btn_border), self._trigger_refresh()))
        self.btn_fill.clicked.connect(lambda: (self._pick_color(self.btn_fill), self._trigger_refresh()))
        self.btn_h_bg.clicked.connect(lambda: (self._pick_color(self.btn_h_bg), self._trigger_refresh()))
        
        # Table changes
        self.tbl_fields.itemChanged.connect(self._trigger_refresh)
        self.tbl_rules.itemChanged.connect(self._trigger_refresh)

    def _trigger_refresh(self):
        self.poly_preview.update()
        self._update_popup_preview()

    def _paint_poly_preview(self, event):
        painter = QPainter(self.poly_preview)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Get style
        b_color = QColor(self.btn_border.text())
        f_color = QColor(self.btn_fill.text())
        width = self.spn_width.value()
        opacity = int(self.sld_op.value() * 2.55) # 0-100 to 0-255
        
        f_color.setAlpha(opacity)
        
        painter.setPen(QPen(b_color, width))
        painter.setBrush(QBrush(f_color))
        
        # Draw a sample polygon (diamond shape)
        points = [Qt.QtCore.QPoint(175, 40), Qt.QtCore.QPoint(300, 100), Qt.QtCore.QPoint(175, 160), Qt.QtCore.QPoint(50, 100)]
        painter.drawPolygon(Qt.QtGui.QPolygon(points))

    def _update_popup_preview(self):
        layers = QgsProject.instance().mapLayersByName(self.cbo_layers.currentText())
        if not layers: return
        feat = next(layers[0].getFeatures(), None)
        if feat:
            data = {f.name(): feat[f.name()] for f in feat.fields()}
            html = HtmlTemplateBuilder(self._get_current_config()).build(data)
            self.html_preview.setHtml(html)

    def _setup_tab_kml2shp(self):
        layout = QVBoxLayout(self.tab_kml2shp)
        layout.addWidget(QLabel("KML File:")); self.txt_kml_in = QLineEdit(); layout.addWidget(self.txt_kml_in)
        layout.addWidget(QLabel("Target CRS:")); self.txt_crs = QLineEdit("EPSG:4326"); layout.addWidget(self.txt_crs)
        btn = QPushButton("🔄 EXTRACT NOW"); btn.clicked.connect(self._convert_kml); layout.addWidget(btn); layout.addStretch()

    def _setup_tab_guide(self):
        layout = QVBoxLayout(self.tab_guide); self.guide = QTextEdit(); self.guide.setReadOnly(True); layout.addWidget(self.guide)

    def _setup_tab_author(self):
        layout = QVBoxLayout(self.tab_author); self.author = QTextEdit(); self.author.setReadOnly(True); layout.addWidget(self.author)

    def _refresh_ui_text(self):
        self.setWindowTitle("LVT have KML view _V006")
        self.btn_lang.setText("🌐 " + ("English" if self.lang == 'vi' else "Tiếng Việt"))
        self.guide.setHtml(get_help(self.lang))
        # (Other translations same as V005...)

    def _toggle_language(self): self.lang = 'en' if self.lang == 'vi' else 'vi'; self._refresh_ui_text(); self._trigger_refresh()

    def _pick_color(self, btn):
        color = QColorDialog.getColor(QColor(btn.text()))
        if color.isValid(): btn.setText(color.name()); btn.setStyleSheet(f"background-color: {color.name()}")

    def _add_rule(self):
        r = self.tbl_rules.rowCount(); self.tbl_rules.insertRow(r)
        cb = QComboBox(); layers = QgsProject.instance().mapLayersByName(self.cbo_layers.currentText())
        if layers: cb.addItems([f.name() for f in layers[0].fields()])
        self.tbl_rules.setCellWidget(r, 0, cb); self.tbl_rules.setCellWidget(r, 1, QComboBox()); self.tbl_rules.cellWidget(r,1).addItems(["=", ">", "<"])
        self.tbl_rules.setItem(r, 2, QTableWidgetItem("")); self.tbl_rules.setCellWidget(r, 3, QPushButton("#C62828")); self.tbl_rules.setCellWidget(r, 4, QPushButton("#FFF5F5"))
        self._trigger_refresh()

    def _del_rule(self): self.tbl_rules.removeRow(self.tbl_rules.currentRow()); self._trigger_refresh()

    def _on_layer_changed(self):
        layers = QgsProject.instance().mapLayersByName(self.cbo_layers.currentText())
        if layers: self._update_fields(layers[0]); self._trigger_refresh()

    def _update_fields(self, layer):
        fnames = [f.name() for f in layer.fields()]
        self.cbo_name1.clear(); self.cbo_name1.addItems(fnames); self.cbo_name2.clear(); self.cbo_name2.addItems(fnames)
        self.tbl_fields.setRowCount(0)
        for i, name in enumerate(fnames):
            self.tbl_fields.insertRow(i); chk = QCheckBox(); chk.setChecked(True); self.tbl_fields.setCellWidget(i, 0, chk)
            self.tbl_fields.setItem(i, 1, QTableWidgetItem(name)); self.tbl_fields.setItem(i, 2, QTableWidgetItem(name)); self.tbl_fields.setItem(i, 3, QTableWidgetItem(""))

    def _get_current_config(self):
        # Simplified for preview logic
        rules = []
        for i in range(self.tbl_rules.rowCount()):
            rules.append({
                'field': self.tbl_rules.cellWidget(i,0).currentText() if self.tbl_rules.cellWidget(i,0) else "",
                'operator': self.tbl_rules.cellWidget(i,1).currentText() if self.tbl_rules.cellWidget(i,1) else "=",
                'value': self.tbl_rules.item(i,2).text() if self.tbl_rules.item(i,2) else "",
                'text_color': self.tbl_rules.cellWidget(i,3).text() if self.tbl_rules.cellWidget(i,3) else "#000",
                'bg_color': self.tbl_rules.cellWidget(i,4).text() if self.tbl_rules.cellWidget(i,4) else "#fff",
                'bold': True, 'italic': False
            })
        df = []
        for i in range(self.tbl_fields.rowCount()):
            chk = self.tbl_fields.cellWidget(i,0)
            if chk and chk.isChecked(): df.append({'field': self.tbl_fields.item(i,1).text(), 'alias': self.tbl_fields.item(i,2).text(), 'suffix': self.tbl_fields.item(i,3).text(), 'order': i})
        return {
            'name_fields': {'field1': self.cbo_name1.currentText(), 'field2': self.cbo_name2.currentText(), 'separator': self.txt_sep.text(), 'font_size': 12},
            'description_fields': df, 'polygon_style': {'border_color': self.btn_border.text(), 'border_width': self.spn_width.value(), 'fill_color': self.btn_fill.text(), 'fill_opacity': self.sld_op.value()},
            'header': {'title': self.txt_h_title.text(), 'bg_color': self.btn_h_bg.text(), 'text_color': "#FFFFFF", 'bold': True, 'font_size': 14},
            'row_highlights': {'enabled': self.chk_row_hl.isChecked(), 'rules': rules}
        }

    def _load_current_layers(self):
        self.cbo_layers.clear()
        for layer in QgsProject.instance().mapLayers().values(): self.cbo_layers.addItem(layer.name())

    def _export(self):
        out_path, _ = QFileDialog.getSaveFileName(self, "Save KML/KMZ", "", "KML (*.kml);;KMZ (*.kmz)")
        if not out_path: return
        layers = QgsProject.instance().mapLayersByName(self.cbo_layers.currentText())
        if not layers: return
        builder = KmlBuilder(self._get_current_config())
        success, msg = builder.build(layers[0], out_path, 'kmz' if out_path.lower().endswith('.kmz') else 'kml')
        if success: QMessageBox.information(self, "Success", tr('msg_success', self.lang))

    def _convert_kml(self): pass # Implemented in V005
